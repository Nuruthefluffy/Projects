// import utilities
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        varint var = new varint();


        // initialize variables
        int strikes = 3;
        char anschar;
        char corans;
        String ans;
        int wordlength;
        int wordlengthnow;
        int length;
        String fillerchar = "_";
        String word;
        String hint;
        // get input and determine word size
        Scanner input = new Scanner(System.in);
        System.out.println("enter secret word player 1");
        word = input.nextLine();
        System.out.println("enter hint");
        hint = input.nextLine();
        wordlength = word.length();
        length = wordlength;
        wordlengthnow = wordlength;

        // use length value display original word blank
        for (int i = 0; i < 100; i++) {
            System.out.println(" ");
        }
        System.out.println("player 2, your word is:");
        while (length > 0) {
            System.out.print("_");
            length = length - 1;
        }

        // create array to show word guessing completion
        System.out.println("");
        char[] ansl = new char[wordlength];
        for (int fill = wordlength - 1; fill > -1; fill--) {
            ansl[fill] = fillerchar.charAt(0);
        }

        // loop to prompt for inputs, determines if answer is right or wrong, moves on to next letter if answer is correct
        // displays remaining strikes and word completion
        while (wordlengthnow > 0) {
            corans = word.charAt(wordlength - wordlengthnow);
            System.out.println("strikes: " + strikes);
            System.out.println("your hint is: " + hint);
            System.out.println("guess letter (first letter in line is used)");
            ans = input.nextLine();
            // typecast input to character
            anschar = ans.charAt(0);
            if (corans == anschar) {
                System.out.println("hooray");
                // fill out array as words are complete
                ansl[wordlength - wordlengthnow] = corans;
                System.out.println(ansl);
                // move on to next letter
                wordlengthnow = wordlengthnow - 1;
            } else strikes = strikes - 1;
            if (strikes<1) {
                // end game if all strikes are used up
                System.out.println("game over idiot");
                System.exit(0);
            }
        }
    }
}