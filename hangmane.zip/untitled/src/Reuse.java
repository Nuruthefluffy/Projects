public class Reuse {
    static int times = 0;
    static int checklist = 0;
    public static char[] touse = new char[999999999];
    public static boolean Recheck(char use, int leng){
        for (checklist = leng; checklist - leng < leng + 1; checklist++){
            if (touse[checklist - leng] == use){
                return false;
            }
        }
        return true;
    }
    public static void Readd(char ans){
        touse[times] = ans;
        times++;
    }
}
