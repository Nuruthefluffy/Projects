public class stat {
    static String state5 = " _______\n" +
            "  |/     |\n" +
            "  |     (_)\n" +
            "  |     \\|/\n" +
            "  |      |\n" +
            "  |     / \\\n" +
            "  |\n" +
            "__|__";
    static String state4 = " _______\n" +
            "  |/     |\n" +
            "  |     (_)\n" +
            "  |     \\|/\n" +
            "  |      |\n" +
            "  |     / \n" +
            "  |\n" +
            "__|__";
    static String state3 = "_______\n" +
            "  |/     |\n" +
            "  |     (_)\n" +
            "  |     \\|/\n" +
            "  |      |\n" +
            "  |      \n" +
            "  |\n" +
            "__|__";
    static String state2 = "_______\n" +
            "  |/     |\n" +
            "  |     (_)\n" +
            "  |      |/\n" +
            "  |      |\n" +
            "  |      \n" +
            "  |\n" +
            "__|__";
    static String state1 = "  _______\n" +
            "  |/     |\n" +
            "  |     (_)\n" +
            "  |      |\n" +
            "  |      |\n" +
            "  |      \n" +
            "  |\n" +
            "__|__";
    static String state =" _______\n" +
            "  |/     |\n" +
            "  |     (x)\n" +
            "  |      \n" +
            "  |      \n" +
            "  |      \n" +
            "  |\n" +
            "__|__";
    public static String man(int x){
        if (x==5) return state5;
        else if (x==4) return state4;
        else if (x==3) return state3;
        else if (x==2) return state2;
        else if (x==1) return state1;
        else if (x==0) return state;
        return null;
    }
}
