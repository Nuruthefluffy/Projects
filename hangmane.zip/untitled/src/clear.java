public class clear {

    public static void clearfunc(int x){
        for (int i = 0; i < x; i++) {
            System.out.println(" ");
        }
    }
}
