// import utilities
import java.util.Scanner;

public class hangman {
    public static void main(String[] args) {

        varint var = new varint();


        // get input and determine word size
        Scanner input = new Scanner(System.in);
        System.out.println("enter secret word player 1");
        var.word = input.nextLine();
        System.out.println("enter hint");
        var.hint = input.nextLine();
        var.wordlength = var.word.length();
        var.length = var.wordlength;
        var.wordlengthnow = var.wordlength;

        clear.clearfunc(250);
        // use length value display original word blank
        System.out.println("player 2, your word is:");
        while (var.length > 0) {
            System.out.print("_");
            var.length = var.length - 1;
        }

        // create array to show word guessing completion
        System.out.println("");
        char[] ansl = new char[var.wordlength];
        for (int fill = var.wordlength - 1; fill > -1; fill--) {
            ansl[fill] = var.fillerchar.charAt(0);
        }

        // loop to prompt for inputs, determines if answer is right or wrong, moves on to next letter if answer is correct
        // displays remaining strikes and word completion
        char[] guess = new char[var.wordlength + 4];
        for (int fillist = var.wordlength + 3; fillist >= 0; fillist--) {
            guess[fillist] = var.fillerchar.charAt(0);
        }
        while (var.wordlengthnow > 0) {
            var.corans = var.word.charAt(var.wordlength - var.wordlengthnow);
            System.out.println(var.wordlength);
            System.out.println("strikes: " + var.strikes);
            System.out.println("your hint is: " + var.hint);
            System.out.println(stat.man(var.strikes));
            System.out.println("guess letter (first letter in line is used)");
            var.ans = input.nextLine();
            // typecast input to character
            var.anschar = var.ans.charAt(0);
            guess[var.guessint] = var.anschar;
            var.guessint++;
            for (var.anscheck = var.wordlength - 1; var.anscheck >= 0; var.anscheck--) {
                if (var.anschar == var.word.charAt(var.anscheck)) {
                    ansl[var.anscheck] = var.anschar;
                    var.right = true;
                    if (Reuse.Recheck(var.anschar, var.wordlength)) continue; else {var.right = false; continue;}
                }
            }
            if (var.right) {
                Reuse.Readd(var.anschar);
                clear.clearfunc(5);
                var.right = false;
                System.out.println("hooray");
                // fill out array as words are complete
                // move on to next letter
                var.wordlengthnow = var.wordlengthnow - 1;
            } else {var.strikes = var.strikes - 1; clear.clearfunc(1);} System.out.println(ansl);
            System.out.print("your guesses are: ");
            System.out.println(guess);
            if (var.strikes<1) {
                // end game if all strikes are used up
                System.out.println("game over idiot");
                System.out.println(stat.man(0));
                System.exit(69);
            }
        }
    }
}