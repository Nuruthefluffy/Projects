public class varint {
    boolean right;
    int anscheck;
    int strikes = 5;
    char anschar;
    char corans;
    String ans;
    int wordlength;
    int wordlengthnow;
    int length;
    String fillerchar = "_";
    String word;
    String hint;

    int guessint = 0;
}
