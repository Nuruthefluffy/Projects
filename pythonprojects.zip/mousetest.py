import pyautogui
import time
import numpy
import serial
x = 0
y = 0
serialsend = 0

def listToString(s):
   
    strcon = " "
   

    return (strcon.join(s))
while True:
 x, y = pyautogui.position()
 x = numpy.interp(x, [0, 1919], [0, 180])
 y = numpy.interp(y, [0, 1079], [180, 0])
 x = round(x)
 y = round(y)
 serialsend = str(x), ":", str(y)
 serialsend = listToString(serialsend)
 print(serialsend)
 #serialsend = bytes(serialsend, 'utf-8')
 #print(serialsend)
 #ser = serial.Serial('COM7') 
 #ser.baudrate = 9600 #set desired baud rate 
 #ser.write(serialsend)
